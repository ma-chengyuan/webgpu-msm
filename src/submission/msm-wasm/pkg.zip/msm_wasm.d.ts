/* tslint:disable */
/* eslint-disable */
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_8(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_8(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_8(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_8(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_9(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_9(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_9(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_9(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_10(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_10(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_10(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_10(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_11(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_11(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_11(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_11(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_12(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_12(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_12(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_12(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_13(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_13(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_13(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_13(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_14(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_14(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_14(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_14(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_15(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_15(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_15(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_15(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_16(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_16(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_16(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_16(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_20(scalars_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_20(scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_20(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_20(raw_buckets: Uint32Array): Uint32Array;
/**
* @param {number} window_size
* @param {Uint32Array} scalars_flat
* @returns {Uint32Array}
*/
export function split_dynamic(window_size: number, scalars_flat: Uint32Array): Uint32Array;
/**
* @param {number} window_size
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @returns {Uint32Array}
*/
export function msm_end_to_end_dynamic(window_size: number, scalars_flat: Uint32Array, points_flat: Uint32Array): Uint32Array;
/**
* @param {number} window_size
* @param {Uint32Array} scalars_flat
* @param {Uint32Array} points_flat
* @param {number} num_idle_threads
* @returns {Uint32Array}
*/
export function msm_end_to_end_dynamic_with_idle(window_size: number, scalars_flat: Uint32Array, points_flat: Uint32Array, num_idle_threads: number): Uint32Array;
/**
* @param {number} window_size
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_dynamic(window_size: number, raw_buckets: Uint32Array): Uint32Array;
/**
* @param {number} window_size
* @param {Uint32Array} raw_buckets
* @returns {Uint32Array}
*/
export function inter_bucket_reduce_last_dynamic(window_size: number, raw_buckets: Uint32Array): Uint32Array;
/**
* @param {Uint32Array} a
* @param {Uint32Array} b
* @returns {Uint32Array}
*/
export function point_add_affine(a: Uint32Array, b: Uint32Array): Uint32Array;
/**
* @param {number} num_threads
* @returns {Promise<any>}
*/
export function initThreadPool(num_threads: number): Promise<any>;
/**
* @param {number} receiver
*/
export function wbg_rayon_start_worker(receiver: number): void;
/**
*/
export class wbg_rayon_PoolBuilder {
  free(): void;
/**
* @returns {number}
*/
  numThreads(): number;
/**
* @returns {number}
*/
  receiver(): number;
/**
*/
  build(): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly split_8: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_8: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_8: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_8: (a: number, b: number, c: number) => void;
  readonly split_9: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_9: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_9: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_9: (a: number, b: number, c: number) => void;
  readonly split_10: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_10: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_10: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_10: (a: number, b: number, c: number) => void;
  readonly split_11: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_11: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_11: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_11: (a: number, b: number, c: number) => void;
  readonly split_12: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_12: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_12: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_12: (a: number, b: number, c: number) => void;
  readonly split_13: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_13: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_13: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_13: (a: number, b: number, c: number) => void;
  readonly split_14: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_14: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_14: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_14: (a: number, b: number, c: number) => void;
  readonly split_15: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_15: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_15: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_15: (a: number, b: number, c: number) => void;
  readonly split_16: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_16: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_16: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_16: (a: number, b: number, c: number) => void;
  readonly split_20: (a: number, b: number, c: number) => void;
  readonly msm_end_to_end_20: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly inter_bucket_reduce_20: (a: number, b: number, c: number) => void;
  readonly inter_bucket_reduce_last_20: (a: number, b: number, c: number) => void;
  readonly split_dynamic: (a: number, b: number, c: number, d: number) => void;
  readonly msm_end_to_end_dynamic: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly msm_end_to_end_dynamic_with_idle: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
  readonly inter_bucket_reduce_dynamic: (a: number, b: number, c: number, d: number) => void;
  readonly inter_bucket_reduce_last_dynamic: (a: number, b: number, c: number, d: number) => void;
  readonly point_add_affine: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly __wbg_wbg_rayon_poolbuilder_free: (a: number) => void;
  readonly wbg_rayon_poolbuilder_numThreads: (a: number) => number;
  readonly wbg_rayon_poolbuilder_receiver: (a: number) => number;
  readonly wbg_rayon_poolbuilder_build: (a: number) => void;
  readonly initThreadPool: (a: number) => number;
  readonly wbg_rayon_start_worker: (a: number) => void;
  readonly memory: WebAssembly.Memory;
  readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __wbindgen_thread_destroy: (a?: number, b?: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {SyncInitInput} module
* @param {WebAssembly.Memory} maybe_memory
*
* @returns {InitOutput}
*/
export function initSync(module: SyncInitInput, maybe_memory?: WebAssembly.Memory): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
* @param {WebAssembly.Memory} maybe_memory
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: InitInput | Promise<InitInput>, maybe_memory?: WebAssembly.Memory): Promise<InitOutput>;
